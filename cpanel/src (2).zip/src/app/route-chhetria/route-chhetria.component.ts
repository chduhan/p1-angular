import { Component } from '@angular/core';

@Component({
  selector: 'app-route-chhetria',
  templateUrl: './route-chhetria.component.html',
  styleUrl: './route-chhetria.component.css'
})
export class RouteChhetriaComponent {

}
