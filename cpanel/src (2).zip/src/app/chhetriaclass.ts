export class personalInfo{
    chhetriaName!: string;
    chhetriaID!: number;
    chhetriaLogin!: string;
    chhetriaEmail!: string;
}