import { Component } from '@angular/core';

@Component({
  selector: 'app-quote02',
  templateUrl: './quote02.component.html',
  styleUrl: './quote02.component.css'
})
export class Quote02Component {

}
