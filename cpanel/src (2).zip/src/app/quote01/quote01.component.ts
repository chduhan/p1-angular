import { Component } from '@angular/core';

@Component({
  selector: 'app-quote01',
  templateUrl: './quote01.component.html',
  styleUrl: './quote01.component.css'
})
export class Quote01Component {

}
