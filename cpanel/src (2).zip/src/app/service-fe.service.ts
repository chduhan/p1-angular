import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceFEService {

  constructor() { }
  serviceInfo (){
    alert ("Final Exam For Aakriti chhetri/ chhetria /991702857");

  }
}
